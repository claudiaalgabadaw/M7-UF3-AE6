package m7.uf3.AE6Spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ae6SpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
