CREATE TABLE IF NOT EXISTS restaurantes."reservas" (
    rest_id uuid NOT NULL,
    name VARCHAR(20) NOT NULL,
    capacity INTEGER NOT NULL,
    food_type VARCHAR(20) NOT NULL,
    owner_name VARCHAR(20) NOT NULL,
    PRIMARY KEY (rest_id)
);