package m7.uf3.AE6Spring.infrastructure.rest.domain;

import java.util.UUID;

public class ReservaTO {
    private String name;
    private Integer capacity;
    private String foodType;
    private String ownerName;

    public ReservaTO(String name, Integer capacity, String foodType, String ownerName) {
        this.name = name;
        this.capacity = capacity;
        this.foodType = foodType;
        this.ownerName = ownerName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    public String getFoodType() {
        return foodType;
    }

    public void setFoodType(String foodType) {
        this.foodType = foodType;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }
}
