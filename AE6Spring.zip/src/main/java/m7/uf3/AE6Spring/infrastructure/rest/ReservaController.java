package m7.uf3.AE6Spring.infrastructure.rest;

import m7.uf3.AE6Spring.application.ReservaService;
import m7.uf3.AE6Spring.domain.Reserva;
import m7.uf3.AE6Spring.infrastructure.rest.domain.ReservaTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/reserva")

public class ReservaController {

    @Autowired
    private ReservaService reservaService;

    @PostMapping("/createReserva")
    @ResponseStatus(HttpStatus.OK)
    public Reserva createReserva(@RequestBody ReservaTO reserva) {
        return reservaService.createReserva(reserva);
    }

    @GetMapping("/{reservaId}")
    @ResponseStatus(HttpStatus.OK)
    public ReservaTO getReserva(@PathVariable String reservaId){
        return reservaService.getReserva(reservaId);
    }

    /*@DeleteMapping("/{reservaId}")
    @ResponseStatus(HttpStatus.OK)
    public void deleteReserva(@PathVariable String reservaId) {
        reservaService.deleteReserva(reservaId);
    }*/
}
