package m7.uf3.AE6Spring.infrastructure.repositories;

import m7.uf3.AE6Spring.domain.Reserva;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository

public interface ReservaRepository extends JpaRepository<Reserva, Long> {
    Optional<Reserva> findByRestId(UUID rest_id);
}
