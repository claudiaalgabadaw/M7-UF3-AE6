package m7.uf3.AE6Spring.application;

import m7.uf3.AE6Spring.domain.Reserva;
import m7.uf3.AE6Spring.infrastructure.repositories.ReservaRepository;
import m7.uf3.AE6Spring.infrastructure.rest.domain.ReservaTO;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.Optional;
import java.util.UUID;

@Component
public class ReservaService {
    private final ReservaRepository reservaRepository;

    @Inject
    public ReservaService(ReservaRepository reservaRepository){
        this.reservaRepository = reservaRepository;
    }

    public Reserva createReserva(ReservaTO reserva){
        Reserva reservaJPA = new Reserva(UUID.randomUUID(),reserva.getName(),reserva.getCapacity(), reserva.getFoodType(), reserva.getOwnerName());
        return reservaRepository.save(reservaJPA);
    }

    public ReservaTO getReserva(String rest_id) {
        UUID uuidReserva = UUID.fromString(rest_id);
        Optional<Reserva> reservaOptional =  reservaRepository.findByRestId(uuidReserva);
        if (!reservaOptional.isPresent()){
            throw new RuntimeException();
        }
        Reserva reservaJPA = reservaOptional.get();
        ReservaTO reserva = new ReservaTO(reservaJPA.getName(), reservaJPA.getCapacity(), reservaJPA.getFoodType(), reservaJPA.getOwnerName());
        return reserva;
    }

    /*public Reserva updateReserva(String rest_id, String newOwnerName){
        ReservaTO reserva = getReserva(rest_id);
        reserva.setOwnerName(newOwnerName);
        return reservaRepository.save(reserva);
    }

    public void deleteReserva(String rest_id) {
        ReservaTO reserva = getReserva(rest_id);
        reservaRepository.delete(reserva);
    }*/
}
