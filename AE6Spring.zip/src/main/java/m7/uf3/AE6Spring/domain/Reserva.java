package m7.uf3.AE6Spring.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.util.UUID;

@Entity
@Table(name = "reservas", schema = "restaurantes")

public class Reserva {
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public String getFoodType() {
        return foodType;
    }

    public void setFoodType(String foodType) {
        this.foodType = foodType;
    }

    @Id
    @Column(name = "rest_id")
    private UUID restId;
    @Column(name = "name")
    private String name;
    @Column(name = "capacity")
    private Integer capacity;
    @Column(name = "food_type")
    private String foodType;
    @Column(name = "owner_name")
    private String ownerName;

    public Reserva(UUID restId, String name, Integer capacity, String foodType, String ownerName) {
        this.restId = restId;
        this.name = name;
        this.capacity = capacity;
        this.foodType = foodType;
        this.ownerName = ownerName;
    }

    public Reserva(String name, Integer capacity, String foodType, String ownerName) {
        this.restId = UUID.randomUUID();
        this.name = name;
        this.capacity = capacity;
        this.foodType = foodType;
        this.ownerName = ownerName;
    }

    public Reserva() {}

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }
}
