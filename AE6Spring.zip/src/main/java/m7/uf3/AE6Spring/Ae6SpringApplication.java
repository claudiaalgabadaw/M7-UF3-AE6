package m7.uf3.AE6Spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ae6SpringApplication {
	public static void main(String[] args) {
		SpringApplication.run(Ae6SpringApplication.class, args);
	}
}